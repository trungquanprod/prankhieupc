<?php
session_start();
include '../config.php';
include '../head.php';
if($_SESSION['username'] == 'lequocanhadm13'){
?>
</style><br>
<div class="row">
    <div class="col-lg-12">
        <div class="card-box">
            <h4 class="header-title mt-0"><i class="fa fa-dollar-sign"></i> Chuyển tiền</h4>
                        <div class="panel-body">
      <br>
           <form action ="#" method="post">
<div class="input-group input-group-sm">
   <label>#Enter Username </label>&nbsp;&nbsp;&nbsp;&nbsp;
  <input type="text" name="username"
  <?php
$req = mysqli_query($ketnoi, "SELECT * FROM `account`");
while($res = mysqli_fetch_assoc($req)){
?>
<?php
}
?>
    class="form-control" placeholder="Nhập UserName...">

</div><br/>
<div class="input-group input-group-sm">
<label>#Enter Money </label>&nbsp;&nbsp;&nbsp;&nbsp;  
<input type="number" name="vnd" class="form-control" placeholder="Nhập số tiền muốn cộng..."value="<?= $res['username'] ?>">
</div><br/>
<button name="submit" type="submit" class="btn btn-success btn-rounded"><i class="fa fa-dollar-sign"></i> Thực hiện</button>
</div>

</div>
</div>
</div>

</div></div>
</div>
</div>

<?php
if(isset($_POST['submit'])){
$username = $_POST['username'];
$vnd = $_POST['vnd'];
mysqli_query($ketnoi, "UPDATE `account` SET `VND`=`VND`-'$vnd' WHERE `username`='$username'");
echo '<script type="text/javascript">swal("Thành Công","Đã Thêm '.$vnd.' VNĐ Cho '.$username.'","success");setTimeout(function(){ location.href = "/" },1000);</script>'; 
}
}
else
die('Phát Hiện Rồi Nha ! Lewlew ^.^ Mấy Con Chó Ngu ~~');
?>
</div>
</div>
