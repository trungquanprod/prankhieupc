
<?php
session_start();
if(empty($_SESSION['username'])){
	session_destroy();
	header('location: /');
	die();
}
include('../config.php');
include('../head.php');
date_default_timezone_set("Asia/Ho_Chi_Minh");
$hethong = mysqli_fetch_array(mysqli_query($ketnoi, "SELECT * FROM `hethong_quantri` WHERE `id` = '1'"));

if($data['facebook'] == ''){
    exit('<script type="text/javascript">swal("Thông Báo","Vui Lồng Cập Nhập Thông Tin!!!","warning"); setTimeout(function(){ location.href = "/update.php" },2000);</script>');
}
if($data['ban'] == '1'){
    exit('<script type="text/javascript">swal("Thông Báo","Tài Khoản Của Bạn Đã Bị Khóa!!!","error"); setTimeout(function(){ location.href = "/thoat.php" },1);</script>');
} 
?>
<?php
$trangmuc = 'trangchinh';
if(isset($_POST['hoanthanh'])) {
$tieude = $_POST[tieude];
$logosite = $_POST[logosite];
$mota = $_POST[mota];
$tukhoa = $_POST[tukhoa];
$tenmien = $_POST[tenmien];
$anhmota = $_POST[anhmota];
$hotline = $_POST[hotline];
$chushop = $_POST[chushop];
$facebook_chushop = $_POST[facebook_chushop];
$thongbao = $_POST[thongbao];
$logo = $_POST[logo];
mysqli_query($ketnoi, "UPDATE `hethong_quantri` SET
`tieude` = '". $tieude ."',
`logosite` = '". $logosite ."',
`mota` = '". $mota ."',
`tukhoa` = '". $tukhoa ."',
`tenmien` = '". $tenmien ."',
`anhmota` = '". $anhmota ."',
`hotline` = '". $hotline ."',
`chushop` = '". $chushop ."',
`facebook_chushop` = '". $facebook_chushop ."',
`thongbao` = '". $thongbao ."',
`logo` = '". $logo ."'
WHERE id='1'");
?>
<?php
//load_url(setting('domain')."/hoanganh_caidat/");
}
?>
<?php
$hoanganh = mysqli_fetch_array(mysqli_query($ketnoi, "SELECT * FROM `hethong_quantri` WHERE id='1'"));?>
<div class="row">
    <div class="col-lg-12">
        <div class="card-box">
            <h4 class="header-title mt-0"><i class="fa fa-cog"></i> Settings</h4>
            <br>
            <form action="" id="settingsSaves" method="POST" accept-charset="utf-8">
                <input type="hidden" name="t" value="settings">
                <ul class="nav nav-tabs">
                    <li class="nav-item"><a href="#website" data-toggle="tab" aria-expanded="false" class="nav-link active"><span class="d-block d-sm-none"><i class="fas fa-home"></i></span><span class="d-none d-sm-block">Website</span></a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane fade show active" id="website">
                        <div class="form-group">
                            <label>Title Web:</label>
<input type="text" name="tieude" class="form-control form-control-danger" placeholder="Tiêu đề mặc định cho trang web" value="<?=$hoanganh[tieude]?>">                        </div>
                        <div class="form-group">
                            <label>Tên Bên Trong  :</label>
<input type="text" name="logosite" class="form-control form-control-danger" placeholder="Tên Site" value="<?=$hoanganh[logosite]?>">
                        </div>
                        
                        <div class="form-group ">
                            <label>Màu Site</label>
                            <div id="cp3" class="input-group colorpicker-component colorpicker-element  r" data-colorpicker-id="1">
<input type="text" class="form-control" name="logo" value="<?=$hoanganh[logo]?>">                            </div>
<div class="form-group">
                            <label>Thông Báo Trang Chủ</label>
                            <div id="cp3" class="input-group colorpicker-component colorpicker-element" data-colorpicker-id="1">
<input type="text" class="form-control" name="anhmota" value="<?=$hoanganh[anhmota]?>">                            </div>
<div class="form-group">
                             <label>Trạng Thái </label>
 <select id="hotline"  name="hotline" class="form-control">
      <option value="1">Bật</option>             
      <option value="2">Tắt<option>   
      </select>
      </div>

                        </div>
                       
                    </div>
                 
                    <button type="submit" name="hoanthanh" class="btn btn-default btn-block btn-dark"><i class="fa fa-cog"></i> Lưu cài đặt</button>
                </div>
            </form>
        </div>
    </div>
    