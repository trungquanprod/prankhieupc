<?php
session_start();
if(empty($_SESSION['username'])){
	session_destroy();
	header('location: /');
	die();
}
include('../config.php');
include('../head.php');
date_default_timezone_set("Asia/Ho_Chi_Minh");
if($data['facebook'] == ''){
    exit('<script type="text/javascript">swal("Thông Báo","Vui Lồng Cập Nhập Thông Tin!!!","warning"); setTimeout(function(){ location.href = "/update.php" },2000);</script>');
}
if($data['ban'] == '1'){
    exit('<script type="text/javascript">swal("Thông Báo","Tài Khoản Của Bạn Đã Bị Khóa!!!","error"); setTimeout(function(){ location.href = "/thoat.php" },1);</script>');
} 
?>
<?php
$trangmuc = 'thanhvien';
require_once('../config.php');
switch($_GET['hethong']){
case'khoa':
$id = htmlspecialchars(strip_tags($_GET[id]));
$dulieu_thanhvien = mysqli_fetch_array(mysqli_query($ketnoi, "SELECT * FROM `account` WHERE id = '$id'"));
if($dulieu_thanhvien['ban'] == 0){
mysqli_query($ketnoi, "UPDATE `account` SET `ban`='1' WHERE id = '$id' LIMIT 1");
    exit('<script type="text/javascript">swal("Thông Báo","Khóa Tài Khoán Thành Công","succes"); setTimeout(function(){ location.href = "/" },2000);</script>');
}
header('location: thanhvien.php/?');
break;
case'mokhoa':
$id = htmlspecialchars(strip_tags($_GET[id]));
$dulieu_thanhvien = mysqli_fetch_array(mysqli_query($ketnoi, "SELECT * FROM `account` WHERE id = '$id'"));
if($dulieu_thanhvien['ban'] == 1){
mysqli_query($ketnoi, "UPDATE `account` SET `ban`='0' WHERE id = '$id' LIMIT 1");
    exit('<script type="text/javascript">swal("Thông Báo","Mở Tài Khoán Thành Công","succes"); setTimeout(function(){ location.href = "/" },2000);</script>');

}
header('location: thanhvien.php/?');
break;
case'xoa':
$id = htmlspecialchars(strip_tags($_GET[id]));
$dulieu_thanhvien = mysqli_fetch_array(mysqli_query($ketnoi, "SELECT * FROM `account` WHERE id = '$id'"));
if($dulieu_thanhvien['usename'] == 'lequocanhadm13' || $dulieu_thanhvien['usename'] == 'lequocanhadm13'){
header('location: thanhvien.php');
}else{
mysqli_query($ketnoi, "DELETE FROM `account` WHERE id = '$id' LIMIT 1");
    exit('<script type="text/javascript">swal("Thông Báo","Xóa Tài Khoán Thành Công","succes"); setTimeout(function(){ location.href = "/" },2000);</script>');

}
header('location: thanhvien.php/?');
break;
default:
if (isset($_GET["page"])) { $page  = $_GET["page"]; } else { $page=1; };
$num_rec_per_page=30;
$start_from = ($page-1) * $num_rec_per_page;
$total_records = mysqli_num_rows(mysqli_query($ketnoi, "SELECT * FROM account"));
$total_pages = ceil($total_records / $num_rec_per_page);
?>
<div class="row">
    <div class="col-lg-12">
        <div class="card-box">
            <h4 class="header-title mt-0"><i class="mdi mdi-account"></i> Users</h4>
            <br>
            <div class="table-responsive">
                <div id="DataTables_Table_0_wrapper" class="dataTables_wrapper dt-bootstrap4 no-footer">
                    <div class="row">
                        <div class="col-sm-12 col-md-6">
                            <div class="dataTables_length" id="DataTables_Table_0_length">
                                <label>Hiển thị
                                    <select name="DataTables_Table_0_length" aria-controls="DataTables_Table_0" class="custom-select custom-select-sm form-control form-control-sm">
                                        <option value="5">5</option>
                                        <option value="10">10</option>
                                        <option value="25">25</option>
                                        <option value="50">50</option>
                                        <option value="100">100</option>
                                        <option value="200">200</option>
                                        <option value="500">500</option>
                                        <option value="1000">1,000</option>
                                        <option value="-1">Tất cả</option>
                                    </select> kết quả</label>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div id="DataTables_Table_0_filter" class="dataTables_filter">
                                <label>Tìm kiếm :
                                    <input type="search" class="form-control form-control-sm" placeholder="Từ khóa..." aria-controls="DataTables_Table_0">
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12">
                            <table class="dataTables table table-bordered table-hover text-center dataTable no-footer" id="DataTables_Table_0" role="grid" aria-describedby="DataTables_Table_0_info">
                                <thead>
                                    <tr role="row">
                                         <th>STT</th>
        <th>Full Name</th>
        <th>Tên Tài Khoản</th>
       	<th>Mật Khẩu</th>
       	<th>VNĐ</th>	
       	<th>Hành Động</th>
                                    </tr>
                                </thead>
                                <tbody>
        <?php
				$result = mysqli_query($ketnoi,"SELECT * FROM `account` ORDER BY id DESC LIMIT 10000 ");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
               <tr>
                <td><?php echo $row['id']; ?></td>
                 <td><?php echo $row['fullname']; ?></td>
                  <td><h5 class="mb-3 text-primary"><?php echo $row['username']; ?></h5></td>
                 <td><?php echo $row['password']; ?></td>
                 <td><?php echo $row['VND']; ?></td>
                
              <td><?php if($row['ban'] == 0){ ?>
 <a href="thanhvien.php?hethong=khoa&id=<?=$row['id']?>" 
 ><button class="btn btn-danger btn-sm" type="button">Khóa</button>
 </a>
 
<?php }elseif($row['ban'] == 1){ ?>
 <a href="thanhvien.php?hethong=mokhoa&id=<?=$row['id']?>"><button class="btn btn-danger btn-sm" type="button">Mở Khóa</button></a>
<?php } ?>
 <a href="thanhvien.php?hethong=xoa&id=<?=$row['id']?>"><button class="btn btn-danger btn-sm" type="button">Xóa</button></a></td>
 
</tr>
<?php } }}?>
             </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-12 col-md-5">
                            <div class="dataTables_info" id="DataTables_Table_0_info" role="status" aria-live="polite">Hiển thị trang 1 trong tổng số 19 trang</div>
                        </div>
                        <div class="col-sm-12 col-md-7">
                            <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                <ul class="pagination">
                                    <li class="paginate_button page-item previous disabled" id="DataTables_Table_0_previous"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="0" tabindex="0" class="page-link">Previous</a>
                                    </li>
                                    <li class="paginate_button page-item active"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="1" tabindex="0" class="page-link">1</a>
                                    </li>
                                    <li class="paginate_button page-item "><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="2" tabindex="0" class="page-link">2</a>
                                    </li>
                                    <li class="paginate_button page-item "><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="3" tabindex="0" class="page-link">3</a>
                                    </li>
                                    <li class="paginate_button page-item "><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="4" tabindex="0" class="page-link">4</a>
                                    </li>
                                    <li class="paginate_button page-item "><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="5" tabindex="0" class="page-link">5</a>
                                    </li>
                                    <li class="paginate_button page-item disabled" id="DataTables_Table_0_ellipsis"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="6" tabindex="0" class="page-link">…</a>
                                    </li>
                                    <li class="paginate_button page-item "><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="7" tabindex="0" class="page-link">19</a>
                                    </li>
                                    <li class="paginate_button page-item next" id="DataTables_Table_0_next"><a href="#" aria-controls="DataTables_Table_0" data-dt-idx="8" tabindex="0" class="page-link">Next</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>