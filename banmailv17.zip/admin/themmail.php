<?php
include('../config.php');
if($username != $admin){
    die("Cút");
    exit;
}
if(isset($_GET['hotmail'])){
	$hotmail = $_GET['hotmail'];
	$loai = $_GET['loai'];

			if($loai == 1){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `hotmail` WHERE `hotmail` = '".$hotmail."' AND `loai` = '1'"))) {
				mysqli_query($ketnoi,"UPDATE `hotmail` SET `hotmail` = '".$hotmail."' WHERE `hotmail` = ".$hotmail."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `hotmail` SET `hotmail` = '".$hotmail."',`loai` = '1'");
				echo 'insert';
			}
			}
			if($loai == 2){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `hotmail` WHERE `hotmail` = '".$hotmail."' AND `loai` = '2'"))) {
				mysqli_query($ketnoi,"UPDATE `hotmail` SET `hotmail` = '".$hotmail."' WHERE `hotmail` = ".$hotmail."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `hotmail` SET `hotmail` = '".$hotmail."',`loai` = '2'");
				echo 'insert';
			}
			}
			if($loai == 3){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `hotmail` WHERE `hotmail` = '".$hotmail."' AND `loai` = '3'"))) {
				mysqli_query($ketnoi,"UPDATE `hotmail` SET `hotmail` = '".$hotmail."' WHERE `hotmail` = ".$hotmail."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `hotmail` SET `hotmail` = '".$hotmail."',`loai` = '3'");
				echo 'insert';
			}
			}
			if($loai == 4){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `hotmail` WHERE `hotmail` = '".$hotmail."' AND `loai` = '4'"))) {
				mysqli_query($ketnoi,"UPDATE `hotmail` SET `hotmail` = '".$hotmail."' WHERE `hotmail` = ".$hotmail."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `hotmail` SET `hotmail` = '".$hotmail."',`loai` = '4'");
				echo 'insert';
			}
			}

			if($loai == 5){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `hotmail` WHERE `hotmail` = '".$hotmail."' AND `loai` = '5'"))) {
				mysqli_query($ketnoi,"UPDATE `hotmail` SET `hotmail` = '".$hotmail."' WHERE `hotmail` = ".$hotmail."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `hotmail` SET `hotmail` = '".$hotmail."',`loai` = '5'");
				echo 'insert';
			}
			}
			if($loai == 6){
			if(mysqli_num_rows(mysqli_query($ketnoi,"SELECT * FROM `hotmail` WHERE `hotmail` = '".$hotmail."' AND `loai` = '6'"))) {
				mysqli_query($ketnoi,"UPDATE `hotmail` SET `hotmail` = '".$hotmail."' WHERE `hotmail` = ".$hotmail."");
				echo 'update';
			}else{
				mysqli_query($ketnoi,"INSERT INTO `hotmail` SET `hotmail` = '".$hotmail."',`loai` = '6'");
				echo 'insert';
			}
			}
			
			
	exit();
}
include('../head.php');
?>
 <div class="row">
    <div class="col-lg-12">
        <div class="card-box">
            <h4 class="header-title mt-0"><i class="fa fa-cog"></i> Thêm Mail</h4>
			<div class="panel-body">
	<div class="form-group">
				
					<textarea rows="20" cols="300" type="text" class="form-control" id="listhotmail"  placeholder="..."></textarea>
					</div>
					
					<div class="form-group has-error has-feedback">
            <select id="loai" class="form-control">
		    <option value="1"><? echo $loai1; ?></option>
			<option value="2"><? echo $loai2; ?></option>
			<option value="3"><? echo $loai3; ?></option>
			<option value="4"><? echo $loai4; ?></option>
			<option value="5"><? echo $production5; ?></option>
			<option value="6"><? echo $production6; ?></option>

		</select>
        </div>
					<div class="form-group">
						<button type="button" class="btn btn-primary" id="btn" onclick="addtoken();">Thêm</button>
					</div>
					<div id='an' style= 'display:none'>
					 Update :<div id='update'>0</div>
					 Insert :<div id='insert'>0</div>
					 Die :<div id='die'>0</div>
					</div>
                </div>
            </div>
        </div><br>
<script type="text/javascript">
    function addtoken() {
		var insert = 0, update = 0, die = 0;
        var listhotmail = $('#listhotmail').val();
		var loai = $('#loai').val();
        if (listhotmail == '') {
            toarst("error", "Vui Lòng Nhập list mail", "Thông Báo Lỗi !!!");
            return false;
        }
		$('#an').show();
		$('#btn').prop('disabled', true)
		var hotmail = listhotmail.split('\n');
		var c = hotmail.length;
		for(i = 0; i < c; i++){
		var vuong = hotmail[i].trim();
        $.get('themmail.php', {
            hotmail: vuong,
			loai:loai
        }, function(data, status) {
			if(data == '')
			{
				die++;
				$('#die').text(die);
			}
			if(data == 'insert')
			{
				insert++;
				$('#insert').text(insert);	
			}
			if(data == 'update')
			{
				update++;
				$('#update').text(update);
			}
           $('#btn').prop('disabled', false)
        });
		}
    }
</script>
  <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4"> 2020 - &copy; <a href="#" title="">Lê Quốc Anh</a>
                </div>
                <div class="col-md-4"></div>
            </div>
        </div>
    </footer>
    <div class="rightbar-overlay"></div>
    <script src="/assets/libs/datatables/jquery.dataTables.min.js"></script>
    <script src="/assets/libs/datatables/dataTables.bootstrap4.js"></script>
    <script src="/assets/libs/datatables/dataTables.responsive.min.js"></script>
    <script src="/assets/libs/datatables/responsive.bootstrap4.min.js"></script>
    <script src="/assets/js/app.min.js"></script>
    <script src="/assets/js/base.js"></script>
    <script>
        ;
        $(document).ready(function() {
            $('[name="like_type"], [name="sub_type"], [name="share_type"], [name="cmt_type"], [name="like_page_type"]').prop('selectedIndex', 1).change().keyup()
        });
    </script>