 <?php
session_start();
include '../config.php';
include '../head.php';

if($_SESSION['username'] == 'lequocanhadm13')

?>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card-box">
                        <h4 class="header-title mt-0"><i class="mdi mdi-clock"></i> History</h4>
                        <br>
                        <div class="table-responsive">
                            <table class="dataTables table table-bordered table-hover text-center">
                                <thead>
                                    <tr>
                                       <th>UID</th>
        <th>Hoạt Động</th>
       	<th>Thời Gian</th>
                                    </tr>
                                </thead>
                                <tbody>
        <?php
				$result = mysqli_query($ketnoi,"SELECT * FROM `hoatdong` ORDER BY id DESC LIMIT 0,999999 ");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
               <tr>
                 <td><h5 class="mb-3 text-success"><?php echo $row['id']; ?></h5></td>
                 <td><h5 class="mb-3 text-primary"><?php echo $row['note']; ?></h5></td>
                 <td><h5 class="mb-3 text-warning"><?php echo $row['time']; ?></h5></td>
                            </tr>
<?php
}
}
?>
             </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="form-group" id = "mess"></div>
<?php
break;
die('Phát Hiện Rồi Nha ! Lewlew ^.^ Mấy Con Chó Ngu ~~');
?>