$('[data-toggle="tooltip"]').tooltip();

function api (a) {
	return '/api/' + a;
}

function number_format (t) {
   return parseFloat(t).toFixed(0).replace(/./g, function (c, i, a) {
       return i && c !== "." && ((a.length - i) % 3 === 0) ? ',' + c : c;
   });
}

function getPrice (f = 'form#service') {
    if ($('body').find(f).length === 0) {
        return false;
    }
    if (location.pathname.includes('/fb/')) {
        uri = 'service/facebook/price';
    }
    if (location.pathname.includes('/ig/')) {
        uri = 'service/instagram/price';
    }
    $.post(api(uri), $(f).serializeArray(), function (a) {
        $.each(a, (k, v) => {
            $('div.price-content').find('.' + k).html(v);
        });
    });
}

function move (u = '') {
	if (u == '') {
		window.location = window.location;
	} else {
		window.location = u;
	}
}

$.ajaxSetup({
    cache: false,
    beforeSend: function () {
        $('button, button.btn, .btn').addClass('btn-process');
    },
    complete: function () {
        $('button, button.btn, .btn').removeClass('btn-process');
    }
});

$('form#service').bind('submit', function (e) {
    target = $(this).find('button[data-target]').data('target');
    p = $('span.price-over-text').html() + "<br>";
    p += 'Tá»•ng thanh toÃ¡n lÃ  : <font color="green" style="font-weight:bold;">'+ $('span.price-text').html() +'</font>';
    swal({
        title: 'Cháº¯c cháº¯n mua?',
        html: p,
        type: 'warning',
        confirmButtonText: 'Äá»“ng Ã½',
        cancelButtonText: 'Há»§y Bá»',
        showCancelButton: true,
        cancelButtonColor: swalCancelColor
    }).then(function () {
        $.post(api(target), $('form#service').serializeArray(), function (a) {
            if (a.status > 0) {
                swal('GREAT!', a.message, a.swal_type).then(function () {
                    if (a.move) {
                        move(a.move);
                    }
                });
            } else {
                swal('OOPS!', a.message, a.swal_type);
            }
        });
    });
    e.preventDefault();
});

$(function () {
    $.fn.dataTable.ext.errMode = 'none';
    $('.dataTables').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': true,
        'order': [
            [0, 'desc']
        ],
        'pageLength': 25,
        'lengthMenu': [[5, 10, 25, 50, 100, 200, 500, 1000, -1], [5, 10, 25, 50, 100, 200, 500, 1000, "Táº¥t cáº£"]],
        'language': {
            'info': 'Hiá»ƒn thá»‹ trang _PAGE_ trong tá»•ng sá»‘ _PAGES_ trang',
            'searchPlaceholder': 'Tá»« khÃ³a...',
            'search': 'TÃ¬m kiáº¿m :',
            'zeroRecords': 'KhÃ´ng tÃ¬m tháº¥y káº¿t quáº£...',
            'infoEmpty': 'KhÃ´ng tÃ¬m tháº¥y káº¿t quáº£...',
            'lengthMenu': 'Hiá»ƒn thá»‹ _MENU_ káº¿t quáº£'
        }
    });
});